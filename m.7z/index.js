const Discord = require("discord.js");
const { Client, Intents, Permissions, Collection } = require("discord.js");
const { Routes } = require("discord-api-types/v9");
const { clientId, guildId } = require("./config.json");
const config = require('./config.json');
const fs = require("fs");
const generated = new Set();
const server = require('./server.js');
const commands = require('./deploy-commands.js')
const AdminSystem = require('./admin-system.js');
const VouchSystem = require('./vouch-system.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_INVITES, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.MESSAGE_CONTENT] });

const inviteSystem = new InviteSystem();
const adminSystem = new AdminSystem();
const vouchSystem = new VouchSystem();
let inviteCache = new Map();

client.commands = new Collection();
const commandFiles = fs
  .readdirSync("./commands")
  .filter((file) => file.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}!`);
  client.user.setActivity(`${config.status}`, { type: "STREAMING", url: "https://twitch.tv/gluxgen" }); // Set the bot's activity status
    /* You can change the activity type to:
     * LISTENING
     * WATCHING
     * COMPETING
     * STREAMING (you need to add a twitch.tv url next to type like this:   { type: "STREAMING", url: "https://twitch.tv/twitch_username_here"} )
     * PLAYING (default)
    */

  // Cache all current invites
  try {
    const guild = client.guilds.cache.get(guildId);
    if (guild) {
      // Check if bot has permission to manage invites
      const botMember = guild.members.cache.get(client.user.id);
      if (botMember && botMember.permissions.has('MANAGE_GUILD')) {
        const invites = await guild.invites.fetch();
        inviteCache.clear();
        invites.forEach(invite => {
          inviteCache.set(invite.code, { uses: invite.uses, inviter: invite.inviter });
        });
        console.log('✅ Invite cache initialized');
      } else {
        console.log('⚠️  Missing MANAGE_GUILD permission for invite tracking');
      }
    }
  } catch (error) {
    console.log('⚠️  Could not initialize invite cache - missing permissions');
  }
});

// Handle member join events
client.on('guildMemberAdd', async (member) => {
  try {
    const guild = member.guild;
    const newInvites = await guild.invites.fetch();

    let usedInvite = null;
    let inviter = null;

    // Find which invite was used
    newInvites.forEach(invite => {
      const cachedInvite = inviteCache.get(invite.code);
      if (cachedInvite && invite.uses > cachedInvite.uses) {
        usedInvite = invite;
        inviter = cachedInvite.inviter;
      }
    });

    // Update cache
    inviteCache.clear();
    newInvites.forEach(invite => {
      inviteCache.set(invite.code, { uses: invite.uses, inviter: invite.inviter });
    });

    if (inviter && usedInvite) {
      // Calculate account age in days
      const accountAge = Math.floor((Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24));

      // Add invite to system
      const { isFake, isRejoin } = inviteSystem.addInvite(
        inviter.id, 
        member.id, 
        member.user.tag, 
        accountAge
      );

      // Get updated stats
      const inviterStats = inviteSystem.getUserInvites(inviter.id);

      // Send welcome message
      const welcomeChannel = guild.channels.cache.get('1390002759511707850'); // Replace with your welcome channel ID
      if (welcomeChannel) {
        let statusText = '';
        if (isFake) {
          statusText = ' <:cross:1390238873086464072> (Fake Account - Under 3 months)';
        } else if (isRejoin) {
          statusText = ' <:refresh:1390238936747474954> (Rejoin)';
        }

        const message = `<:black_presente:1390239083527143468> <@${member.id}> joined who was invited by <@${inviter.id}>! They now have **${inviterStats.totalInvites}** total invites (**${inviterStats.validInvites}** valid)${statusText}`;
        welcomeChannel.send(message);
      }
    }
  } catch (error) {
    console.error('Error handling member join:', error);
  }
});

// Handle invite creation/deletion to update cache
client.on('inviteCreate', (invite) => {
  inviteCache.set(invite.code, { uses: invite.uses, inviter: invite.inviter });
});

client.on('inviteDelete', (invite) => {
  inviteCache.delete(invite.code);
});

// Handle mentions and prefix commands
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // Check if bot is mentioned
  if (message.mentions.has(client.user) && !message.content.startsWith(config.prefix)) {
    const embed = new Discord.MessageEmbed()
      .setTitle('<:black_presente:1390239083527143468> Soch Gen Bot')
      .setDescription('I am a gen bot with vouch feature! Please use `/help` for my commands.')
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 512 }))
      .setColor(config.color.default)
      .addFields([
        { name: '<:black:1390239496993374230> Quick Commands', value: '`/help` - View all commands\n`/free` - Generate free reward\n`/premium` - Generate premium reward', inline: false },
        { name: '<:black_presente:1390239083527143468> Vouch Commands', value: '`+vouch @user positive/negative <message>` - Vouch for a user\n`+vouches [@user]` - View vouches\n`+vouchleaderboard` - View leaderboard', inline: false },
        { name: '<:NC_Black_Link:1390239310229274688> Links', value: `[Website](${config.website})`, inline: false }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
    return;
  }

  // Handle prefix commands
  if (!message.content.startsWith(config.prefix)) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  try {
    // Help command
    if (command === 'help') {
      const embed = new Discord.MessageEmbed()
        .setTitle('<:black_presente:1390239083527143468> Soch Gen - Premium Command Center')
        .setDescription(`**Welcome ${message.author}!** Here are all available commands:`)
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 512 }))
        .setImage(config.banner)
        .setColor(config.color.default)
        .addFields([
          {
            name: '<:black_presente:1390239083527143468> **Generator Commands**',
            value: '```diff\n+ /help - Display command list\n+ /create - Create new service\n+ /free - Generate free reward\n+ /premium - Generate premium reward\n+ /add - Add reward to stock\n+ /stock - View current stock```',
            inline: false
          },
          {
            name: '<:NC_Black_Link:1390239310229274688> **Invite System**',
            value: '```diff\n+ /invites - Check invite stats\n+ /invited - See who you invited\n+ /claim-free-access - Claim role (3 invites)\n+ /leaderboard - Invite leaderboard```',
            inline: false
          },
          {
            name: '<:black_presente:1390239083527143468> **Vouch System (Prefix)**',
            value: '```css\n+vouch @user positive/negative <message>\n+vouches [@user] - View user vouches\n+vouchleaderboard - Top vouched users\n+vouchremove @user <id> - Remove vouch (Admin)\n+vouchclear @user - Clear all vouches (Admin)```',
            inline: false
          },
          {
            name: '<:black_booster:1390239993359896580> **User Commands**',
            value: '```diff\n+ /server-info - Server information\n+ /user-info - User information\n+ /bot-stats - Bot statistics\n+ /avatar - Display user avatar\n+ /ping - Bot latency```',
            inline: false
          },
          {
            name: '<:BlackAdmin:1390240052168228864> **Admin Commands**',
            value: '```diff\n+ /admin-add - Add new admin\n+ /admin-remove - Remove admin\n+ /admin-list - List all admins\n+ /inv-add - Add invites to user\n+ /inv-remove - Remove invites\n+ /clear-chat - Clear messages```',
            inline: false
          },
          {
            name: '<:blackrole:1390239240264089667> **Developer Commands**',
            value: '```diff\n+ /dev-reload - Reload bot modules\n+ /dev-logs - View recent logs\n+ /dev-eval - Execute code\n+ /dev-status - Change bot status\n+ /reload-commands - Reload commands```',
            inline: false
          },
          {
            name: '<:black:1390239496993374230> **Bot Information**',
            value: `\`\`\`yaml\nPrefix: ${config.prefix}\nWebsite: ${config.website}\nStatus: Online 24/7\nVersion: 2.0 Premium\`\`\``,
            inline: false
          }
        ])
        .setFooter({ 
          text: `${config.footer} • Requested by ${message.author.tag}`, 
          iconURL: message.author.displayAvatarURL({ dynamic: true, size: 64 }) 
        })
        .setTimestamp();

      return await message.reply({ embeds: [embed] });
    }

    // Free command
    else if (command === 'free') {
      const freeCommand = client.commands.get('free');
      if (freeCommand) {
        // Create a mock interaction object for prefix commands
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await freeCommand.execute(mockInteraction);
      }
    }

    // Premium command
    else if (command === 'premium') {
      const premiumCommand = client.commands.get('premium');
      if (premiumCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await premiumCommand.execute(mockInteraction);
      }
    }

    // Stock command
    else if (command === 'stock') {
      const stockCommand = client.commands.get('stock');
      if (stockCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await stockCommand.execute(mockInteraction);
      }
    }

    // Invites command
    else if (command === 'invites') {
      const invitesCommand = client.commands.get('invites');
      if (invitesCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          options: {
            getUser: () => message.mentions.users.first() || null
          },
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await invitesCommand.execute(mockInteraction);
      }
    }

    // Bot stats command
    else if (command === 'botstats' || command === 'stats') {
      const botStatsCommand = client.commands.get('bot-stats');
      if (botStatsCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          client: client,
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await botStatsCommand.execute(mockInteraction);
      }
    }

    // Ping command
    else if (command === 'ping') {
      const pingCommand = client.commands.get('ping');
      if (pingCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          client: client,
          createdTimestamp: message.createdTimestamp,
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await pingCommand.execute(mockInteraction);
      }
    }

    // Server info command
    else if (command === 'serverinfo') {
      const serverInfoCommand = client.commands.get('server-info');
      if (serverInfoCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await serverInfoCommand.execute(mockInteraction);
      }
    }

    // Avatar command
    else if (command === 'avatar' || command === 'av') {
      const avatarCommand = client.commands.get('avatar');
      if (avatarCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          options: {
            getUser: () => message.mentions.users.first() || null
          },
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await avatarCommand.execute(mockInteraction);
      }
    }

    // Leaderboard command
    else if (command === 'leaderboard' || command === 'lb') {
      const leaderboardCommand = client.commands.get('leaderboard');
      if (leaderboardCommand) {
        const mockInteraction = {
          user: message.author,
          member: message.member,
          guild: message.guild,
          channel: message.channel,
          options: {
            getInteger: () => parseInt(args[0]) || 10
          },
          reply: async (content) => await message.reply(content),
          editReply: async (content) => await message.edit(content),
          deferReply: async () => {},
          followUp: async (content) => await message.reply(content)
        };
        await leaderboardCommand.execute(mockInteraction);
      }
    }

    // Vouch command
    else if (command === 'vouch') {
      if (args.length < 3) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> Invalid Usage')
          .setDescription('Usage: `+vouch @user positive/negative <message>`')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const targetUser = message.mentions.users.first();
      if (!targetUser) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> User Not Found')
          .setDescription('Please mention a valid user.')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const vouchType = args[1].toLowerCase();
      if (!['positive', 'negative', '+', '-'].includes(vouchType)) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> Invalid Type')
          .setDescription('Vouch type must be `positive`, `negative`, `+`, or `-`.')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const type = vouchType === '+' || vouchType === 'positive' ? 'positive' : 'negative';
      const vouchMessage = args.slice(2).join(' ');

      // Check if user can vouch
      const canVouchResult = vouchSystem.canVouch(message.author.id, targetUser.id);
      if (!canVouchResult.canVouch) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> Cannot Vouch')
          .setDescription(canVouchResult.reason)
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      // Add the vouch
      const vouch = vouchSystem.addVouch(targetUser.id, message.author.id, vouchMessage, type);
      const userVouches = vouchSystem.getUserVouches(targetUser.id);

      const embed = new Discord.MessageEmbed()
        .setTitle(`<:black_presente:1390239083527143468> Vouch ${type === 'positive' ? 'Added' : 'Added'}`)
        .setDescription(`Successfully ${type === 'positive' ? 'vouched for' : 'neg-vouched'} ${targetUser}!`)
        .addFields([
          { name: '<:black_presente:1390239083527143468> Message', value: `\`\`\`${vouchMessage}\`\`\``, inline: false },
          { name: '<:black:1390239496993374230> Score', value: `**${userVouches.score}** (${userVouches.positive.length} positive, ${userVouches.negative.length} negative)`, inline: true },
          { name: '<:BlackAdmin:1390240052168228864> Vouched by', value: `${message.author}`, inline: true }
        ])
        .setColor(type === 'positive' ? config.color.green : config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    }

    // Vouches command
    else if (command === 'vouches') {
      const targetUser = message.mentions.users.first() || message.author;
      const userVouches = vouchSystem.getUserVouches(targetUser.id);

      if (userVouches.total === 0) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> No Vouches')
          .setDescription(`${targetUser} has no vouches yet.`)
          .setColor(config.color.yellow)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const embed = new Discord.MessageEmbed()
        .setTitle(`<:black_presente:1390239083527143468> ${targetUser.username}'s Vouches`)
        .setDescription(`**Score:** ${userVouches.score} | **Total:** ${userVouches.total}`)
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
        .setColor(userVouches.score >= 0 ? config.color.green : config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      // Add positive vouches
      if (userVouches.positive.length > 0) {
        const positiveVouches = userVouches.positive
          .slice(-3) // Show last 3 vouches for prefix command
          .map(v => {
            const date = new Date(v.timestamp).toLocaleDateString();
            return `**Message:** ${v.message}\n**Date:** ${date}`;
          })
          .join('\n\n');

        embed.addFields({ 
          name: `<:black_presente:1390239083527143468> Positive Vouches (${userVouches.positive.length})`, 
          value: positiveVouches.length > 1024 ? positiveVouches.substring(0, 1020) + '...' : positiveVouches,
          inline: false 
        });
      }

      // Add negative vouches
      if (userVouches.negative.length > 0) {
        const negativeVouches = userVouches.negative
          .slice(-3) // Show last 3 vouches for prefix command
          .map(v => {
            const date = new Date(v.timestamp).toLocaleDateString();
            return `**Message:** ${v.message}\n**Date:** ${date}`;
          })
          .join('\n\n');

        embed.addFields({ 
          name: `<:cross:1390238873086464072> Negative Vouches (${userVouches.negative.length})`, 
          value: negativeVouches.length > 1024 ? negativeVouches.substring(0, 1020) + '...' : negativeVouches,
          inline: false 
        });
      }

      await message.reply({ embeds: [embed] });
    }

    // Vouch leaderboard command
    else if (command === 'vouchleaderboard' || command === 'vouchlb') {
      const limit = parseInt(args[0]) || 10;
      const topUsers = vouchSystem.getTopVouched(Math.min(limit, 15));

      if (topUsers.length === 0) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> No Data')
          .setDescription('No vouch data available yet.')
          .setColor(config.color.yellow)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const embed = new Discord.MessageEmbed()
        .setTitle('<:black_presente:1390239083527143468> Vouch Leaderboard')
        .setDescription(`Top ${Math.min(limit, 15)} most vouched users`)
        .setColor(config.color.default)
        .setFooter({ text: config.footer })
        .setTimestamp();

      let leaderboard = '';
      for (let i = 0; i < topUsers.length; i++) {
        const user = topUsers[i];
        const position = i + 1;
        const medal = position === 1 ? '🥇' : position === 2 ? '🥈' : position === 3 ? '🥉' : `**${position}.**`;

        try {
          const discordUser = await client.users.fetch(user.userId);
          leaderboard += `${medal} **${discordUser.username}** - Score: **${user.score}** (${user.positive.length}+ ${user.negative.length}-)\n`;
        } catch (error) {
          leaderboard += `${medal} **Unknown User** - Score: **${user.score}** (${user.positive.length}+ ${user.negative.length}-)\n`;
        }
      }

      embed.setDescription(`Top ${Math.min(limit, 15)} most vouched users\n\n${leaderboard}`);

      await message.reply({ embeds: [embed] });
    }

    // Admin vouch remove command
    else if (command === 'vouchremove') {
      if (!adminSystem.isAdmin(message.author.id)) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> Access Denied')
          .setDescription('Only admins can use this command.')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      if (args.length < 2) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> Invalid Usage')
          .setDescription('Usage: `+vouchremove @user <vouch_id>`')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const targetUser = message.mentions.users.first();
      const vouchId = args[1];

      if (!targetUser) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> User Not Found')
          .setDescription('Please mention a valid user.')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const vouch = vouchSystem.getVouchById(targetUser.id, vouchId);
      if (!vouch) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> Vouch Not Found')
          .setDescription('Could not find a vouch with that ID.')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const removed = vouchSystem.removeVouch(targetUser.id, vouchId);

      if (removed) {
        const userVouches = vouchSystem.getUserVouches(targetUser.id);

        const embed = new Discord.MessageEmbed()
          .setTitle('<:black_presente:1390239083527143468> Vouch Removed')
          .setDescription(`Successfully removed vouch ID \`${vouchId}\` from ${targetUser}.`)
          .addFields([
            { name: '<:black:1390239496993374230> New Score', value: `**${userVouches.score}** (${userVouches.positive.length} positive, ${userVouches.negative.length} negative)`, inline: true },
            { name: '<:BlackAdmin:1390240052168228864> Removed by', value: `${message.author}`, inline: true }
          ])
          .setColor(config.color.green)
          .setFooter({ text: config.footer })
          .setTimestamp();

        await message.reply({ embeds: [embed] });
      }
    }

    // Admin vouch clear command
    else if (command === 'vouchclear') {
      if (!adminSystem.isAdmin(message.author.id)) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> Access Denied')
          .setDescription('Only admins can use this command.')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const targetUser = message.mentions.users.first();
      if (!targetUser) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> User Not Found')
          .setDescription('Please mention a valid user.')
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const userVouches = vouchSystem.getUserVouches(targetUser.id);
      if (userVouches.total === 0) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:cross:1390238873086464072> No Vouches')
          .setDescription(`${targetUser} has no vouches to clear.`)
          .setColor(config.color.yellow)
          .setFooter({ text: config.footer })
          .setTimestamp();
        return await message.reply({ embeds: [embed] });
      }

      const cleared = vouchSystem.clearUserVouches(targetUser.id);

      if (cleared) {
        const embed = new Discord.MessageEmbed()
          .setTitle('<:black_presente:1390239083527143468> Vouches Cleared')
          .setDescription(`Successfully cleared all vouches for ${targetUser}.`)
          .addFields([
            { name: '<:black:1390239496993374230> Previous Stats', value: `Score: **${userVouches.score}** | Total: **${userVouches.total}**`, inline: true },
            { name: '<:BlackAdmin:1390240052168228864> Cleared by', value: `${message.author}`, inline: true }
          ])
          .setColor(config.color.green)
          .setFooter({ text: config.footer })
          .setTimestamp();

        await message.reply({ embeds: [embed] });
      }
    }

  } catch (error) {
    console.error('Error in prefix command handler:', error);
    const embed = new Discord.MessageEmbed()
      .setTitle('<:cross:1390238873086464072> Error')
      .setDescription('An error occurred while processing your command.')
      .setColor(config.color.red)
      .setFooter({ text: config.footer })
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  }
});

client.on('interactionCreate', async interaction => {
	if (interaction.isCommand()) {
		const command = client.commands.get(interaction.commandName);

		if (!command) return;

		try {
			await command.execute(interaction);
		} catch (error) {
			console.error(error);
			await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
		}
	}

	if (interaction.isSelectMenu()) {
		if (interaction.customId === 'help_menu') {
			const { MessageEmbed } = require('discord.js');
			const config = require('./config.json');

			let embed;

			switch (interaction.values[0]) {
				case 'generator':
					embed = new MessageEmbed()
						.setColor(config.color.default)
						.setTitle('<:black_presente:1390239083527143468> Generator Commands')
						.setDescription('Commands for generating and managing rewards')
						.addFields([
							{ name: '/help', value: 'Display command list', inline: true },
							{ name: '/create', value: 'Create new service', inline: true },
							{ name: '/free', value: 'Generate free reward', inline: true },
							{ name: '/premium', value: 'Generate premium reward', inline: true },
							{ name: '/add', value: 'Add reward to stock', inline: true },
							{ name: '/stock', value: 'View current stock', inline: true }
						])
						.setFooter({ text: config.footer })
						.setTimestamp();
					break;

				case 'invite':
					embed = new MessageEmbed()
						.setColor(config.color.default)
						.setTitle('<:NC_Black_Link:1390239310229274688> Invite System')
						.setDescription('Invite tracking and reward commands')
						.addFields([
							{ name: '/invites', value: 'Check invite stats', inline: true },
							{ name: '/invited', value: 'See who you invited', inline: true },
							{ name: '/claim-free-access', value: 'Claim role (3 invites)', inline: true },
							{ name: '/leaderboard', value: 'Invite leaderboard', inline: true }
						])
						.setFooter({ text: config.footer })
						.setTimestamp();
					break;

				case 'vouch':
					embed = new MessageEmbed()
						.setColor(config.color.default)
						.setTitle('<:black_presente:1390239083527143468> Vouch System')
						.setDescription('User vouching and reputation system (Prefix Commands)')
						.addFields([
							{ name: '+vouch @user positive/negative <message>', value: 'Vouch for a user', inline: false },
							{ name: '+vouches [@user]', value: 'View user vouches', inline: true },
							{ name: '+vouchleaderboard', value: 'Top vouched users', inline: true },
							{ name: '+vouchremove @user <id>', value: 'Remove vouch (Admin)', inline: true },
							{ name: '+vouchclear @user', value: 'Clear all vouches (Admin)', inline: true }
						])
						.setFooter({ text: config.footer })
						.setTimestamp();
					break;

				case 'user':
					embed = new MessageEmbed()
						.setColor(config.color.default)
						.setTitle('<:black_booster:1390239993359896580> User Commands')
						.setDescription('General user utility commands')
						.addFields([
							{ name: '/server-info', value: 'Server information', inline: true },
							{ name: '/user-info', value: 'User information', inline: true },
							{ name: '/bot-stats', value: 'Bot statistics', inline: true },
							{ name: '/avatar', value: 'Display user avatar', inline: true },
							{ name: '/ping', value: 'Bot latency', inline: true }
						])
						.setFooter({ text: config.footer })
						.setTimestamp();
					break;

				case 'admin':
					embed = new MessageEmbed()
						.setColor(config.color.default)
						.setTitle('<:BlackAdmin:1390240052168228864> Admin Commands')
						.setDescription('Administrative functions')
						.addFields([
							{ name: '/admin-add', value: 'Add new admin', inline: true },
							{ name: '/admin-remove', value: 'Remove admin', inline: true },
							{ name: '/admin-list', value: 'List all admins', inline: true },
							{ name: '/inv-add', value: 'Add invites to user', inline: true },
							{ name: '/inv-remove', value: 'Remove invites', inline: true },
							{ name: '/clear-chat', value: 'Clear messages', inline: true }
						])
						.setFooter({ text: config.footer })
						.setTimestamp();
					break;

				case 'developer':
					if (interaction.user.id === config.developerId) {
						embed = new MessageEmbed()
							.setColor(config.color.default)
							.setTitle('<:blackrole:1390239240264089667> Developer Commands')
							.setDescription('Developer-only commands')
							.addFields([
								{ name: '/dev-reload', value: 'Reload bot modules', inline: true },
								{ name: '/dev-logs', value: 'View recent logs', inline: true },
								{ name: '/dev-eval', value: 'Execute code', inline: true },
								{ name: '/dev-status', value: 'Change bot status', inline: true },
								{ name: '/reload-commands', value: 'Reload commands', inline: true }
							])
							.setFooter({ text: config.footer })
							.setTimestamp();
					} else {
						embed = new MessageEmbed()
							.setColor(config.color.red)
							.setTitle('Access Denied')
							.setDescription('You do not have permission to view developer commands.')
							.setFooter({ text: config.footer })
							.setTimestamp();
					}
					break;
			}

			await interaction.update({ embeds: [embed] });
		}
	}
});

client.login(process.env.TOKEN);