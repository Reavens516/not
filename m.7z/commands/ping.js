
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const fs = require('fs');

// Enhanced logging function
function logActivity(type, message, userId = null, productId = null, service = null) {
  const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
  const logEntry = `[${timestamp}] TYPE: ${type} | MESSAGE: ${message}${userId ? ` | USER: ${userId}` : ''}${productId ? ` | PRODUCT_ID: ${productId}` : ''}${service ? ` | SERVICE: ${service}` : ''}\n`;
  
  // Write to log file
  fs.appendFileSync('./logs/activity.log', logEntry);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot latency and response time'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const userName = interaction.user.username;
    
    const sent = await interaction.reply({ content: '🏓 Pinging...', fetchReply: true });
    const timeDiff = sent.createdTimestamp - interaction.createdTimestamp;
    
    const embed = new MessageEmbed()
      .setTitle('🏓 Pong!')
      .setColor('#00FF00')
      .addField('📡 Bot Latency', `${timeDiff}ms`, true)
      .addField('💓 API Latency', `${Math.round(interaction.client.ws.ping)}ms`, true)
      .setTimestamp()
      .setFooter({ text: `Requested by ${userName}`, iconURL: interaction.user.displayAvatarURL() });

    await interaction.editReply({ content: null, embeds: [embed] });
    
    logActivity('COMMAND', `Ping command used - Bot: ${timeDiff}ms, API: ${Math.round(interaction.client.ws.ping)}ms`, userId, null, 'PING');
  },
};
