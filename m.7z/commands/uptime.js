
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const os = require('os');

// Enhanced logging function
function logActivity(type, message, userId = null, productId = null, service = null) {
  const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
  const logEntry = `[${timestamp}] TYPE: ${type} | MESSAGE: ${message}${userId ? ` | USER: ${userId}` : ''}${productId ? ` | PRODUCT_ID: ${productId}` : ''}${service ? ` | SERVICE: ${service}` : ''}\n`;
  
  // Write to log file
  fs.appendFileSync('./logs/activity.log', logEntry);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('uptime')
    .setDescription('Check bot and system uptime information'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const userName = interaction.user.username;
    
    // Bot uptime
    const botUptime = process.uptime();
    const botDays = Math.floor(botUptime / 86400);
    const botHours = Math.floor(botUptime / 3600) % 24;
    const botMinutes = Math.floor(botUptime / 60) % 60;
    const botSeconds = Math.floor(botUptime % 60);
    
    // System uptime
    const sysUptime = os.uptime();
    const sysDays = Math.floor(sysUptime / 86400);
    const sysHours = Math.floor(sysUptime / 3600) % 24;
    const sysMinutes = Math.floor(sysUptime / 60) % 60;
    const sysSecs = Math.floor(sysUptime % 60);
    
    // Memory usage
    const memUsage = process.memoryUsage();
    const memUsed = (memUsage.heapUsed / 1024 / 1024).toFixed(2);
    const memTotal = (memUsage.heapTotal / 1024 / 1024).toFixed(2);
    
    const embed = new MessageEmbed()
      .setTitle('⏰ Uptime Information')
      .setColor('#0099FF')
      .addField('🤖 Bot Uptime', `${botDays}d ${botHours}h ${botMinutes}m ${botSeconds}s`, true)
      .addField('🖥️ System Uptime', `${sysDays}d ${sysHours}h ${sysMinutes}m ${sysSecs}s`, true)
      .addField('💾 Memory Usage', `${memUsed}MB / ${memTotal}MB`, true)
      .addField('📊 CPU Usage', `${os.loadavg()[0].toFixed(2)}%`, true)
      .addField('🏛️ Platform', os.platform(), true)
      .addField('🔧 Node.js Version', process.version, true)
      .setTimestamp()
      .setFooter({ text: `Requested by ${userName}`, iconURL: interaction.user.displayAvatarURL() });

    await interaction.reply({ embeds: [embed] });
    
    logActivity('COMMAND', `Uptime command used - Bot: ${botDays}d ${botHours}h ${botMinutes}m, System: ${sysDays}d ${sysHours}h`, userId, null, 'UPTIME');
  },
};
