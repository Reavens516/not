
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');
const util = require('util');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dev-eval')
    .setDescription('[DEV] Execute JavaScript code')
    .addStringOption(option =>
      option.setName('code')
        .setDescription('JavaScript code to execute')
        .setRequired(true)
    ),

  async execute(interaction) {
    const config = require('../config.json');
    
    if (interaction.user.id !== config.developerId) {
      const { MessageEmbed } = require('discord.js');
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Access Denied')
        .setDescription('Only the developer can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();
      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }
    if (!adminSystem.isOwner(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only developers can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const code = interaction.options.getString('code');

    try {
      let evaled = eval(code);
      
      if (typeof evaled !== 'string') {
        evaled = util.inspect(evaled);
      }

      // Truncate if too long
      if (evaled.length > 1900) {
        evaled = evaled.slice(0, 1900) + '...';
      }

      const embed = new MessageEmbed()
        .setTitle('✅ Code Executed')
        .addFields([
          { name: '📥 Input', value: `\`\`\`js\n${code}\`\`\``, inline: false },
          { name: '📤 Output', value: `\`\`\`js\n${evaled}\`\`\``, inline: false }
        ])
        .setColor(config.color.green)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (error) {
      const embed = new MessageEmbed()
        .setTitle('❌ Execution Error')
        .addFields([
          { name: '📥 Input', value: `\`\`\`js\n${code}\`\`\``, inline: false },
          { name: '❌ Error', value: `\`\`\`js\n${error.message}\`\`\``, inline: false }
        ])
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
