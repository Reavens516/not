const { EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  name: "cstatus",
  description: "Verify by checking your custom status",
  run: async (client, message, args) => {
    if (message.author.bot) return;

    const member = message.member;
    const role = message.guild.roles.cache.get(config.verificationRoleId);
    const keyword = config.verificationKeyword.toLowerCase();

    if (!role) {
      return message.reply("Verification role not found. Please check config.json.");
    }

    // Get presence (requires Presence Intent enabled in dev portal + index.js)
    const presence = member.presence;
    if (!presence || !presence.activities || presence.activities.length === 0) {
      const failEmbed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("Verification Failed")
        .setDescription(
          `To get verified:\n\n` +
          `1. **Set your custom status to:**\n\`${config.verificationKeyword}\`\n\n` +
          `2. **Make sure you're not in Invisible mode** (use Online or DND)\n\n` +
          `3. Run \`${config.prefix}cstatus\` again after setting your status`
        )
        .setTimestamp();
      return message.reply({ embeds: [failEmbed] });
    }

    const customStatus = presence.activities.find(a => a.type === 4); // type 4 = custom status
    if (!customStatus || !customStatus.state || !customStatus.state.toLowerCase().includes(keyword)) {
      const failEmbed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("Verification Failed")
        .setDescription(
          `To get verified:\n\n` +
          `1. **Set your custom status to:**\n\`${config.verificationKeyword}\`\n\n` +
          `2. **Make sure you're not in Invisible mode** (use Online or DND)\n\n` +
          `3. Run \`${config.prefix}cstatus\` again after setting your status`
        )
        .setTimestamp();
      return message.reply({ embeds: [failEmbed] });
    }

    // Passed ✅
    if (member.roles.cache.has(role.id)) {
      const embed = new EmbedBuilder()
        .setColor("Green")
        .setTitle("Already Verified")
        .setDescription(`You already have the ${role.name} role.`)
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    await member.roles.add(role);
    const successEmbed = new EmbedBuilder()
      .setColor("Green")
      .setTitle("Verification Successful")
      .setDescription(`You have been given the ${role.name} role.`)
      .setTimestamp();

    return message.reply({ embeds: [successEmbed] });
  }
};
