
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');
const { exec } = require('child_process');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reload-commands')
    .setDescription('[OWNER] Reload bot commands'),

  async execute(interaction) {
    if (!adminSystem.isOwner(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only the bot owner can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    exec('node deploy-commands.js', (error, stdout, stderr) => {
      if (error) {
        const embed = new MessageEmbed()
          .setTitle('❌ Reload Failed')
          .setDescription(`Error: ${error.message}`)
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      }

      const embed = new MessageEmbed()
        .setTitle('✅ Commands Reloaded')
        .setDescription('Successfully reloaded all commands.')
        .setColor(config.color.green)
        .setFooter({ text: config.footer })
        .setTimestamp();

      interaction.editReply({ embeds: [embed] });
    });
  }
};
