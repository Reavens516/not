const { EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
    name: "verify",
    description: "Verify yourself by setting the correct custom status",
    run: async (client, message, args) => {
        const member = message.member;

        // Get custom status
        const activities = member.presence?.activities || [];
        const customStatus = activities.find(a => a.type === 4); // type 4 = custom status

        if (!customStatus || !customStatus.state) {
            return message.reply("❌ You don’t have a custom status set!");
        }

        // Check if it contains the keyword
        if (!customStatus.state.toLowerCase().includes(config.verificationKeyword.toLowerCase())) {
            return message.reply(`❌ Your status must contain **${config.verificationKeyword}** to verify!`);
        }

        // Find the role
        const role = message.guild.roles.cache.find(r => r.name === config.verificationRole);
        if (!role) {
            return message.reply(`⚠️ The role **${config.verificationRole}** doesn’t exist. Please create it first.`);
        }

        // Add role if not already has it
        if (member.roles.cache.has(role.id)) {
            return message.reply("✅ You are already verified!");
        }

        try {
            await member.roles.add(role);
            return message.reply(`✅ You have been verified and given the **${config.verificationRole}** role!`);
        } catch (err) {
            console.error(err);
            return message.reply("❌ I couldn’t give you the role. Check my permissions!");
        }
    }
};
