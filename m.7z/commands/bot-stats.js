
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const config = require('../config.json');
const os = require('os');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bot-stats')
    .setDescription('Display bot statistics'),

  async execute(interaction) {
    const client = interaction.client;
    const uptime = Math.floor(client.uptime / 1000);
    const memoryUsage = process.memoryUsage();
    
    const embed = new MessageEmbed()
      .setTitle('<:black:1390239496993374230> Bot Statistics')
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 512 }))
      .setColor(config.color.default)
      .addFields([
        { name: '<:Black_Drop:1390238711727263855> Uptime', value: `<t:${Math.floor((Date.now() - client.uptime) / 1000)}:R>`, inline: true },
        { name: '<:refresh:1390238936747474954> Ping', value: `${client.ws.ping}ms`, inline: true },
        { name: '<:NC_Black_Link:1390239310229274688> Servers', value: client.guilds.cache.size.toString(), inline: true },
        { name: '<:black_booster:1390239993359896580> Users', value: client.users.cache.size.toString(), inline: true },
        { name: '<:blackrole:1390239240264089667> Channels', value: client.channels.cache.size.toString(), inline: true },
        { name: '<:black_police:1390239611682295808> Commands', value: client.commands.size.toString(), inline: true },
        { name: '<:black_presente:1390239083527143468> Memory', value: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)}MB`, inline: true },
        { name: '<:black_helper:1390239883200692356> Platform', value: os.platform(), inline: true },
        { name: '<:BlackAdmin:1390240052168228864> Node.js', value: process.version, inline: true }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
