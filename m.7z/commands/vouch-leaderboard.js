
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const VouchSystem = require('../vouch-system.js');
const config = require('../config.json');

const vouchSystem = new VouchSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vouch-leaderboard')
    .setDescription('View the vouch leaderboard')
    .addIntegerOption(option =>
      option.setName('limit')
        .setDescription('Number of users to display (max 15)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(15)
    ),

  async execute(interaction) {
    const limit = interaction.options.getInteger('limit') || 10;
    const topUsers = vouchSystem.getTopVouched(limit);

    if (topUsers.length === 0) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> No Data')
        .setDescription('No vouch data available yet.')
        .setColor(config.color.yellow)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed] });
    }

    const embed = new MessageEmbed()
      .setTitle('<:black_presente:1390239083527143468> Vouch Leaderboard')
      .setDescription(`Top ${limit} most vouched users`)
      .setColor(config.color.default)
      .setFooter({ text: config.footer })
      .setTimestamp();

    let leaderboard = '';
    for (let i = 0; i < topUsers.length; i++) {
      const user = topUsers[i];
      const position = i + 1;
      const medal = position === 1 ? '🥇' : position === 2 ? '🥈' : position === 3 ? '🥉' : `**${position}.**`;
      
      try {
        const discordUser = await interaction.client.users.fetch(user.userId);
        leaderboard += `${medal} **${discordUser.username}** - Score: **${user.score}** (${user.positive.length}+ ${user.negative.length}-)\n`;
      } catch (error) {
        leaderboard += `${medal} **Unknown User** - Score: **${user.score}** (${user.positive.length}+ ${user.negative.length}-)\n`;
      }
    }

    embed.setDescription(`Top ${limit} most vouched users\n\n${leaderboard}`);
    
    await interaction.reply({ embeds: [embed] });
  }
};
