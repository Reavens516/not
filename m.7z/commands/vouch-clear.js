
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const VouchSystem = require('../vouch-system.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const vouchSystem = new VouchSystem();
const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vouch-clear')
    .setDescription('[ADMIN] Clear all vouches for a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to clear vouches for')
        .setRequired(true)
    ),

  async execute(interaction) {
    if (!adminSystem.isAdmin(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Access Denied')
        .setDescription('Only admins can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user');
    const userVouches = vouchSystem.getUserVouches(targetUser.id);

    if (userVouches.total === 0) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> No Vouches')
        .setDescription(`${targetUser} has no vouches to clear.`)
        .setColor(config.color.yellow)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const cleared = vouchSystem.clearUserVouches(targetUser.id);
    
    if (cleared) {
      const embed = new MessageEmbed()
        .setTitle('<:black_presente:1390239083527143468> Vouches Cleared')
        .setDescription(`Successfully cleared all vouches for ${targetUser}.`)
        .addFields([
          { name: '<:black:1390239496993374230> Previous Stats', value: `Score: **${userVouches.score}** | Total: **${userVouches.total}**`, inline: true },
          { name: '<:BlackAdmin:1390240052168228864> Cleared by', value: `${interaction.user}`, inline: true }
        ])
        .setColor(config.color.green)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } else {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Error')
        .setDescription('Failed to clear vouches.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
