
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const InviteSystem = require('../invite-system.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const inviteSystem = new InviteSystem();
const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inv-remove')
    .setDescription('[ADMIN] Remove invites from a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to remove invites from')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Number of invites to remove')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    ),

  async execute(interaction) {
    if (!adminSystem.isAdmin(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only admins can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    const data = inviteSystem.getInviteData();
    if (!data[targetUser.id]) {
      const embed = new MessageEmbed()
        .setTitle('❌ No Invites')
        .setDescription(`${targetUser.tag} has no invites to remove.`)
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const currentValid = data[targetUser.id].validInvites;
    const toRemove = Math.min(amount, currentValid);

    data[targetUser.id].validInvites -= toRemove;
    data[targetUser.id].totalInvites -= toRemove;
    inviteSystem.saveInviteData(data);

    const embed = new MessageEmbed()
      .setTitle('✅ Invites Removed')
      .setDescription(`Successfully removed ${toRemove} invites from ${targetUser.tag}.`)
      .setColor(config.color.green)
      .addFields([
        { name: '👤 User', value: targetUser.tag, inline: true },
        { name: '➖ Removed', value: toRemove.toString(), inline: true },
        { name: '📊 New Total', value: data[targetUser.id].validInvites.toString(), inline: true }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
