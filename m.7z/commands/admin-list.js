const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin-list')
    .setDescription('[ADMIN] List all admins'),

  async execute(interaction) {
    if (!adminSystem.isAdmin(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Access Denied')
        .setDescription('Only admins can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const admins = adminSystem.getAllAdmins();
    let adminList = '';

    // Add owner first
    adminList += `<:black:1390239496993374230> <@${adminSystem.BOT_OWNER_ID}> - Owner\n`;

    // Add other admins
    for (const [userId, data] of Object.entries(admins)) {
      if (userId !== adminSystem.BOT_OWNER_ID) {
        const levelEmoji = {
          'admin': '<:black_police:1390239611682295808>',
          'moderator': '<:ModeratorBlack:1390239775486640269>',
          'helper': '<:black_helper:1390239883200692356>'
        };
        adminList += `${levelEmoji[data.level] || '<:black_booster:1390239993359896580>'} <@${userId}> - ${data.level}\n`;
      }
    }

    const embed = new MessageEmbed()
      .setTitle('<:BlackAdmin:1390240052168228864> Admin List')
      .setDescription(adminList || 'No admins found.')
      .setColor(config.color.default)
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};