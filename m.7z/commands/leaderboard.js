
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const InviteSystem = require('../invite-system.js');
const config = require('../config.json');

const inviteSystem = new InviteSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the invite leaderboard')
    .addStringOption(option =>
      option.setName('type')
        .setDescription('Type of leaderboard to show')
        .setRequired(false)
        .addChoices(
          { name: 'Total Invites', value: 'total' },
          { name: 'Valid Invites', value: 'valid' },
          { name: 'Fake Accounts', value: 'fake' },
          { name: 'Rejoins', value: 'rejoin' }
        )
    ),

  async execute(interaction) {
    const type = interaction.options.getString('type') || 'valid';
    const allData = inviteSystem.getInviteData();
    
    // Convert to array and sort
    let sortedUsers = Object.entries(allData).map(([userId, userData]) => ({
      userId,
      ...userData
    }));

    // Sort based on type
    switch (type) {
      case 'total':
        sortedUsers.sort((a, b) => b.totalInvites - a.totalInvites);
        break;
      case 'valid':
        sortedUsers.sort((a, b) => b.validInvites - a.validInvites);
        break;
      case 'fake':
        sortedUsers.sort((a, b) => b.fakeInvites - a.fakeInvites);
        break;
      case 'rejoin':
        sortedUsers.sort((a, b) => b.rejoinInvites - a.rejoinInvites);
        break;
    }

    // Take top 10
    sortedUsers = sortedUsers.slice(0, 10);

    if (sortedUsers.length === 0) {
      const embed = new MessageEmbed()
        .setTitle('<:Black_Drop:1390238711727263855> Invite Leaderboard')
        .setDescription('No invite data found yet!')
        .setColor(config.color.yellow)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed] });
    }

    let description = '';
    const typeLabels = {
      total: 'Total Invites',
      valid: 'Valid Invites',
      fake: 'Fake Accounts',
      rejoin: 'Rejoins'
    };

    for (let i = 0; i < sortedUsers.length; i++) {
      const user = sortedUsers[i];
      const rank = i + 1;
      const medal = rank === 1 ? '<:black:1390239496993374230>' : rank === 2 ? '<:black_police:1390239611682295808>' : rank === 3 ? '<:black_helper:1390239883200692356>' : `${rank}.`;
      
      try {
        const discordUser = await interaction.client.users.fetch(user.userId);
        const count = user[type === 'total' ? 'totalInvites' : type === 'valid' ? 'validInvites' : type === 'fake' ? 'fakeInvites' : 'rejoinInvites'];
        description += `${medal} ${discordUser.username} - **${count}**\n`;
      } catch (error) {
        // User not found, skip
        continue;
      }
    }

    const embed = new MessageEmbed()
      .setTitle(`<:Black_Drop:1390238711727263855> ${typeLabels[type]} Leaderboard`)
      .setDescription(description)
      .setColor(config.color.default)
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
