
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');
const { exec } = require('child_process');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dev-reload')
    .setDescription('[DEV] Reload specific bot modules'),

  async execute(interaction) {
    if (!adminSystem.isOwner(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Access Denied')
        .setDescription('Only developers can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    const embed = new MessageEmbed()
      .setTitle('<:blackrole:1390239240264089667> Development Reload')
      .setDescription('Reloading bot modules...')
      .setColor(config.color.yellow)
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};
