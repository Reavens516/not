
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin-remove')
    .setDescription('[OWNER ONLY] Remove an admin')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to remove admin from')
        .setRequired(true)
    ),

  async execute(interaction) {
    if (!adminSystem.isOwner(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only the bot owner can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user');

    if (!adminSystem.isAdmin(targetUser.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Not Admin')
        .setDescription(`${targetUser.tag} is not an admin.`)
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (adminSystem.isOwner(targetUser.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Cannot Remove Owner')
        .setDescription('Cannot remove the bot owner.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    adminSystem.removeAdmin(targetUser.id);

    const embed = new MessageEmbed()
      .setTitle('✅ Admin Removed')
      .setDescription(`Successfully removed admin privileges from ${targetUser.tag}.`)
      .setColor(config.color.green)
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
