const fs = require("fs");
const path = require("path");
const bannedFile = path.join(__dirname, "../bannedUsers.json");

module.exports = {
  name: "banuser",
  description: "Temporarily ban a user from using /free",
  options: [
    {
      name: "user",
      type: 6, // USER
      description: "The user to ban",
      required: true
    },
    {
      name: "minutes",
      type: 4, // INTEGER
      description: "Ban time in minutes",
      required: true
    },
    {
      name: "reason",
      type: 3, // STRING
      description: "Reason for the ban",
      required: false
    }
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      return interaction.reply({ content: "⛔ You don’t have permission.", ephemeral: true });
    }

    const user = interaction.options.getUser("user");
    const minutes = interaction.options.getInteger("minutes");
    const reason = interaction.options.getString("reason") || "No reason provided";

    let bannedUsers = require("../bannedUsers.json");

    if (bannedUsers.find(b => b.id === user.id)) {
      return interaction.reply({ content: "⚠️ That user is already banned.", ephemeral: true });
    }

    const expiresAt = Date.now() + minutes * 60 * 1000;
    bannedUsers.push({ id: user.id, expiresAt, reason });

    fs.writeFileSync(bannedFile, JSON.stringify(bannedUsers, null, 2));

    interaction.reply(`✅ ${user.tag} banned from /free for ${minutes} minutes. Reason: ${reason}`);
  }
};
