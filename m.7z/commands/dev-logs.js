
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');
const fs = require('fs');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dev-logs')
    .setDescription('[DEV] View recent bot logs')
    .addIntegerOption(option =>
      option.setName('lines')
        .setDescription('Number of log lines to show (default: 20)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(50)
    ),

  async execute(interaction) {
    if (!adminSystem.isOwner(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only developers can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const lines = interaction.options.getInteger('lines') || 20;

    try {
      // Create logs directory if it doesn't exist
      if (!fs.existsSync('./logs')) {
        fs.mkdirSync('./logs');
      }

      // Create log file if it doesn't exist
      if (!fs.existsSync('./logs/activity.log')) {
        fs.writeFileSync('./logs/activity.log', '');
      }

      const logData = fs.readFileSync('./logs/activity.log', 'utf8');
      const logLines = logData.split('\n').filter(line => line.trim() !== '').slice(-lines);

      if (logLines.length === 0) {
        const embed = new MessageEmbed()
          .setTitle('📋 Bot Logs')
          .setDescription('No logs found.')
          .setColor(config.color.yellow)
          .setFooter({ text: config.footer })
          .setTimestamp();

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      const logText = logLines.join('\n');
      const truncatedLogs = logText.length > 4000 ? logText.slice(-4000) : logText;

      const embed = new MessageEmbed()
        .setTitle('📋 Bot Logs')
        .setDescription(`\`\`\`${truncatedLogs}\`\`\``)
        .setColor(config.color.default)
        .setFooter({ text: `Showing last ${logLines.length} lines | ${config.footer}` })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (error) {
      const embed = new MessageEmbed()
        .setTitle('❌ Error')
        .setDescription(`Failed to read logs: ${error.message}`)
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
