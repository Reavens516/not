
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear-chat')
    .setDescription('[ADMIN] Clear messages from the channel')
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Number of messages to delete (1-100)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    ),

  async execute(interaction) {
    if (!adminSystem.isAdmin(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only admins can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const amount = interaction.options.getInteger('amount');

    try {
      const messages = await interaction.channel.bulkDelete(amount, true);
      
      const embed = new MessageEmbed()
        .setTitle('🧹 Messages Cleared')
        .setDescription(`Successfully deleted ${messages.size} messages.`)
        .setColor(config.color.green)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (error) {
      const embed = new MessageEmbed()
        .setTitle('❌ Error')
        .setDescription('Failed to delete messages. Make sure the messages are not older than 14 days.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
