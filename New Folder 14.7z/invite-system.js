
const fs = require('fs');
const path = require('path');

class InviteSystem {
  constructor() {
    this.invitesPath = './data/invites.json';
    this.claimsPath = './data/claims.json';
    this.ensureDataFiles();
  }

  ensureDataFiles() {
    // Create data directory if it doesn't exist
    const dataDir = './data';
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Initialize invites file
    if (!fs.existsSync(this.invitesPath)) {
      fs.writeFileSync(this.invitesPath, JSON.stringify({}));
    }

    // Initialize claims file
    if (!fs.existsSync(this.claimsPath)) {
      fs.writeFileSync(this.claimsPath, JSON.stringify({}));
    }
  }

  getInviteData() {
    try {
      return JSON.parse(fs.readFileSync(this.invitesPath, 'utf8'));
    } catch (error) {
      return {};
    }
  }

  saveInviteData(data) {
    fs.writeFileSync(this.invitesPath, JSON.stringify(data, null, 2));
  }

  getClaimData() {
    try {
      return JSON.parse(fs.readFileSync(this.claimsPath, 'utf8'));
    } catch (error) {
      return {};
    }
  }

  saveClaimData(data) {
    fs.writeFileSync(this.claimsPath, JSON.stringify(data, null, 2));
  }

  addInvite(inviterId, invitedId, invitedTag, accountAge) {
    const data = this.getInviteData();
    
    if (!data[inviterId]) {
      data[inviterId] = {
        totalInvites: 0,
        validInvites: 0,
        fakeInvites: 0,
        rejoinInvites: 0,
        claimInvites: 0,
        invited: []
      };
    }

    const isFake = accountAge < 90; // 3 months in days
    const isRejoin = data[inviterId].invited.some(inv => inv.userId === invitedId);

    const inviteRecord = {
      userId: invitedId,
      userTag: invitedTag,
      joinedAt: Date.now(),
      isFake: isFake,
      isRejoin: isRejoin
    };

    data[inviterId].invited.push(inviteRecord);
    data[inviterId].totalInvites++;

    if (isFake) {
      data[inviterId].fakeInvites++;
    } else if (isRejoin) {
      data[inviterId].rejoinInvites++;
    } else {
      data[inviterId].validInvites++;
    }

    this.saveInviteData(data);
    return { isFake, isRejoin };
  }

  getUserInvites(userId) {
    const data = this.getInviteData();
    return data[userId] || {
      totalInvites: 0,
      validInvites: 0,
      fakeInvites: 0,
      rejoinInvites: 0,
      claimInvites: 0,
      invited: []
    };
  }

  canClaimRole(userId) {
    const userData = this.getUserInvites(userId);
    const claimData = this.getClaimData();
    
    // Check if user has at least 3 valid invites
    if (userData.validInvites < 3) return false;
    
    // Check if user already has an active claim
    if (claimData[userId] && claimData[userId].expiresAt > Date.now()) {
      return false;
    }
    
    return true;
  }

  claimRole(userId) {
    if (!this.canClaimRole(userId)) return false;
    
    const claimData = this.getClaimData();
    const userData = this.getUserInvites(userId);
    
    claimData[userId] = {
      claimedAt: Date.now(),
      expiresAt: Date.now() + (7 * 24 * 60 * 60 * 1000), // 1 week
      invitesUsed: 3
    };
    
    // Deduct 3 invites from valid invites and total invites
    const inviteData = this.getInviteData();
    if (inviteData[userId]) {
      inviteData[userId].validInvites = Math.max(0, inviteData[userId].validInvites - 3);
      inviteData[userId].totalInvites = Math.max(0, inviteData[userId].totalInvites - 3);
      
      // Add to claimInvites if it doesn't exist
      if (!inviteData[userId].claimInvites) {
        inviteData[userId].claimInvites = 0;
      }
      inviteData[userId].claimInvites += 3;
    }
    
    this.saveClaimData(claimData);
    this.saveInviteData(inviteData);
    return true;
  }

  getUserClaim(userId) {
    const claimData = this.getClaimData();
    return claimData[userId] || null;
  }

  isClaimActive(userId) {
    const claim = this.getUserClaim(userId);
    return claim && claim.expiresAt > Date.now();
  }
}

module.exports = InviteSystem;
