
const fs = require('fs');
const path = require('path');

class VouchSystem {
  constructor() {
    this.vouchesFile = path.join(__dirname, 'data', 'vouches.json');
    this.vouches = this.loadVouches();
  }

  loadVouches() {
    try {
      if (fs.existsSync(this.vouchesFile)) {
        const data = fs.readFileSync(this.vouchesFile, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      console.error('Error loading vouches:', error);
    }
    return {};
  }

  saveVouches() {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.vouchesFile);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.vouchesFile, JSON.stringify(this.vouches, null, 2));
    } catch (error) {
      console.error('Error saving vouches:', error);
    }
  }

  addVouch(userId, voucherId, message, type = 'positive') {
    if (!this.vouches[userId]) {
      this.vouches[userId] = {
        positive: [],
        negative: [],
        total: 0,
        score: 0
      };
    }

    const vouch = {
      id: Date.now().toString(),
      voucherId: voucherId,
      message: message,
      timestamp: Date.now(),
      type: type
    };

    this.vouches[userId][type].push(vouch);
    this.updateScore(userId);
    this.saveVouches();
    return vouch;
  }

  removeVouch(userId, vouchId) {
    if (!this.vouches[userId]) return false;

    const positive = this.vouches[userId].positive;
    const negative = this.vouches[userId].negative;

    let removed = false;
    
    // Check positive vouches
    const posIndex = positive.findIndex(v => v.id === vouchId);
    if (posIndex !== -1) {
      positive.splice(posIndex, 1);
      removed = true;
    }

    // Check negative vouches
    const negIndex = negative.findIndex(v => v.id === vouchId);
    if (negIndex !== -1) {
      negative.splice(negIndex, 1);
      removed = true;
    }

    if (removed) {
      this.updateScore(userId);
      this.saveVouches();
    }

    return removed;
  }

  updateScore(userId) {
    if (!this.vouches[userId]) return;

    const positive = this.vouches[userId].positive.length;
    const negative = this.vouches[userId].negative.length;
    
    this.vouches[userId].total = positive + negative;
    this.vouches[userId].score = positive - negative;
  }

  getUserVouches(userId) {
    return this.vouches[userId] || {
      positive: [],
      negative: [],
      total: 0,
      score: 0
    };
  }

  getAllVouches() {
    return this.vouches;
  }

  getTopVouched(limit = 10) {
    const users = Object.entries(this.vouches)
      .map(([userId, data]) => ({ userId, ...data }))
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
    
    return users;
  }

  canVouch(voucherId, targetId) {
    // Users cannot vouch for themselves
    if (voucherId === targetId) {
      return { canVouch: false, reason: 'You cannot vouch for yourself.' };
    }

    // Check if user has already vouched for this person
    const targetVouches = this.getUserVouches(targetId);
    const hasVouched = [...targetVouches.positive, ...targetVouches.negative]
      .some(v => v.voucherId === voucherId);

    if (hasVouched) {
      return { canVouch: false, reason: 'You have already vouched for this user.' };
    }

    return { canVouch: true };
  }

  getVouchById(userId, vouchId) {
    if (!this.vouches[userId]) return null;

    const positive = this.vouches[userId].positive.find(v => v.id === vouchId);
    const negative = this.vouches[userId].negative.find(v => v.id === vouchId);

    return positive || negative || null;
  }

  clearUserVouches(userId) {
    if (this.vouches[userId]) {
      delete this.vouches[userId];
      this.saveVouches();
      return true;
    }
    return false;
  }
}

module.exports = VouchSystem;
