
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageSelectMenu } = require('discord.js');
const config = require('../config.json');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('Display the command list with interactive menu.'),

	async execute(interaction) {
		const mainEmbed = new MessageEmbed()
			.setColor(config.color.default)
			.setTitle('<:black_presente:1390239083527143468> Soch Gen - Premium Command Center')
			.setDescription(`**Welcome ${interaction.user}!** Use the dropdown menu below to explore different command categories.`)
			.setImage(config.banner)
			.setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 }))
			.addFields([
				{
					name: '<:black:1390239496993374230> **Quick Info**',
					value: `\`\`\`yaml\nPrefix: ${config.prefix}\nWebsite: ${config.website}\nStatus: Online 24/7\nVersion: 2.0 Premium\`\`\``,
					inline: false
				}
			])
			.setFooter({ 
				text: `${config.footer} • Requested by ${interaction.user.tag}`, 
				iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) 
			})
			.setTimestamp();

		const selectMenu = new MessageActionRow()
			.addComponents(
				new MessageSelectMenu()
					.setCustomId('help_menu')
					.setPlaceholder('Select a command category')
					.addOptions([
						{
							label: 'Generator Commands',
							description: 'Commands for generating rewards',
							value: 'generator',
							emoji: '<:black_presente:1390239083527143468>'
						},
						{
							label: 'Invite System',
							description: 'Invite tracking and rewards',
							value: 'invite',
							emoji: '<:NC_Black_Link:1390239310229274688>'
						},
						{
							label: 'Vouch System',
							description: 'User vouching commands',
							value: 'vouch',
							emoji: '<:black_presente:1390239083527143468>'
						},
						{
							label: 'User Commands',
							description: 'General user utilities',
							value: 'user',
							emoji: '<:black_booster:1390239993359896580>'
						},
						{
							label: 'Admin Commands',
							description: 'Administrative functions',
							value: 'admin',
							emoji: '<:BlackAdmin:1390240052168228864>'
						}
					])
			);

		// Add developer option only for the developer
		if (interaction.user.id === config.developerId) {
			selectMenu.components[0].addOptions([
				{
					label: 'Developer Commands',
					description: 'Developer-only commands',
					value: 'developer',
					emoji: '<:blackrole:1390239240264089667>'
				}
			]);
		}

		await interaction.reply({ embeds: [mainEmbed], components: [selectMenu] });
	},
};
