
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const InviteSystem = require('../invite-system.js');
const config = require('../config.json');

const inviteSystem = new InviteSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invites')
    .setDescription('Check your invite statistics')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to check invites for (optional)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const userData = inviteSystem.getUserInvites(targetUser.id);
    const claim = inviteSystem.getUserClaim(targetUser.id);

    const embed = new MessageEmbed()
      .setTitle(`${targetUser.username}'s Invite Statistics`)
      .setColor(config.color.default)
      .setThumbnail(targetUser.displayAvatarURL())
      .addFields([
        { name: '<:Black_Drop:1390238711727263855> Total Invites', value: userData.totalInvites.toString(), inline: true },
        { name: '<:black_presente:1390239083527143468> Valid Invites', value: userData.validInvites.toString(), inline: true },
        { name: '<:cross:1390238873086464072> Fake Accounts', value: userData.fakeInvites.toString(), inline: true },
        { name: '<:refresh:1390238936747474954> Rejoins', value: userData.rejoinInvites.toString(), inline: true },
        { name: '<:blackrole:1390239240264089667> Can Claim Role', value: inviteSystem.canClaimRole(targetUser.id) ? 'Yes' : 'No', inline: true },
        { name: '<:black:1390239496993374230> Active Claim', value: inviteSystem.isClaimActive(targetUser.id) ? 'Yes' : 'No', inline: true }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    if (claim && inviteSystem.isClaimActive(targetUser.id)) {
      const expiresIn = Math.floor((claim.expiresAt - Date.now()) / (1000 * 60 * 60 * 24));
      embed.addFields([
        { name: '🏆 Current Claim', value: `Expires in ${expiresIn} days`, inline: false }
      ]);
    }

    await interaction.reply({ embeds: [embed] });
  }
};
