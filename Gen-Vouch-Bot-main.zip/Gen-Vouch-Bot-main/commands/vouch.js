
const { SlashCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");
const VouchSystem = require("../vouch-system.js");
const config = require("../config.json");

const vouchSystem = new VouchSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName("vouch")
    .setDescription("Vouch for a user")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("User to vouch for")
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("message")
        .setDescription("Vouch message/reason")
        .setRequired(true),
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser("user");
    const message = interaction.options.getString("message");

    // Check if user can vouch
    const canVouchResult = vouchSystem.canVouch(interaction.user.id, targetUser.id);
    if (!canVouchResult.canVouch) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Cannot Vouch')
        .setDescription(canVouchResult.reason)
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();
      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Add the vouch (always positive now)
    const vouch = vouchSystem.addVouch(
      targetUser.id,
      interaction.user.id,
      message,
      'positive'
    );

    const guild = interaction.guild;
    const vouchChannel = guild.channels.cache.get(config.vouchChannelId);

    if (vouchChannel) {
      const publicMessage = `<:black_presente:1390239083527143468> ${interaction.user.username} has vouched for ${targetUser.username}!\n**Message:** \`\`\`${message}\`\`\``;
      await vouchChannel.send(publicMessage);
    }

    const embed = new MessageEmbed()
      .setTitle("<:black_presente:1390239083527143468> Vouch Added")
      .setDescription(`Successfully vouched for ${targetUser}!`)
      .addField(
        "<:black_presente:1390239083527143468> Message",
        `\`\`\`${message}\`\`\``,
      )
      .setColor(config.color.green)
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
