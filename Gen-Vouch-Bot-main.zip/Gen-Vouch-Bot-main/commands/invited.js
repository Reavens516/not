
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const InviteSystem = require('../invite-system.js');
const config = require('../config.json');

const inviteSystem = new InviteSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invited')
    .setDescription('View list of users you have invited')
    .addIntegerOption(option =>
      option.setName('page')
        .setDescription('Page number to view')
        .setRequired(false)
        .setMinValue(1)
    ),

  async execute(interaction) {
    const userData = inviteSystem.getUserInvites(interaction.user.id);
    const page = interaction.options.getInteger('page') || 1;
    const itemsPerPage = 10;
    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;

    if (userData.invited.length === 0) {
      const embed = new MessageEmbed()
        .setTitle('No Invites Found')
        .setDescription('You haven\'t invited anyone yet!')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed] });
    }

    const totalPages = Math.ceil(userData.invited.length / itemsPerPage);
    const currentPageItems = userData.invited.slice(startIndex, endIndex);

    let description = '';
    currentPageItems.forEach((invite, index) => {
      const number = startIndex + index + 1;
      const status = invite.isFake ? '❌ Fake' : invite.isRejoin ? '🔄 Rejoin' : '✅ Valid';
      const joinDate = new Date(invite.joinedAt).toLocaleDateString();
      description += `${number}. ${invite.userTag} - ${status} (${joinDate})\n`;
    });

    const embed = new MessageEmbed()
      .setTitle(`${interaction.user.username}'s Invited Users`)
      .setDescription(description)
      .setColor(config.color.default)
      .setFooter({ text: `${config.footer} • Page ${page}/${totalPages}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
