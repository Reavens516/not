
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('user-info')
    .setDescription('Display user information')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to get info about (optional)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(targetUser.id);
    
    const embed = new MessageEmbed()
      .setTitle(`👤 ${targetUser.tag} User Info`)
      .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 512 }))
      .setColor(config.color.default)
      .addFields([
        { name: '🆔 User ID', value: targetUser.id, inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:F>`, inline: false },
        { name: '📅 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`, inline: false },
        { name: '🎭 Roles', value: member.roles.cache.map(role => role.name !== '@everyone' ? `<@&${role.id}>` : '').filter(r => r).join(', ') || 'None', inline: false },
        { name: '🤖 Bot', value: targetUser.bot ? 'Yes' : 'No', inline: true },
        { name: '💎 Nitro', value: targetUser.flags?.has('NITRO') ? 'Yes' : 'Unknown', inline: true }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
