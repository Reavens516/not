
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const VouchSystem = require('../vouch-system.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const vouchSystem = new VouchSystem();
const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vouch-remove')
    .setDescription('[ADMIN] Remove a vouch by ID')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to remove vouch from')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('vouch_id')
        .setDescription('ID of the vouch to remove')
        .setRequired(true)
    ),

  async execute(interaction) {
    if (!adminSystem.isAdmin(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Access Denied')
        .setDescription('Only admins can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user');
    const vouchId = interaction.options.getString('vouch_id');

    // Check if vouch exists
    const vouch = vouchSystem.getVouchById(targetUser.id, vouchId);
    if (!vouch) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Vouch Not Found')
        .setDescription('Could not find a vouch with that ID.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Remove the vouch
    const removed = vouchSystem.removeVouch(targetUser.id, vouchId);
    
    if (removed) {
      const userVouches = vouchSystem.getUserVouches(targetUser.id);
      
      const embed = new MessageEmbed()
        .setTitle('<:black_presente:1390239083527143468> Vouch Removed')
        .setDescription(`Successfully removed vouch ID \`${vouchId}\` from ${targetUser}.`)
        .addFields([
          { name: '<:black:1390239496993374230> New Score', value: `**${userVouches.score}** (${userVouches.positive.length} positive, ${userVouches.negative.length} negative)`, inline: true },
          { name: '<:BlackAdmin:1390240052168228864> Removed by', value: `${interaction.user}`, inline: true }
        ])
        .setColor(config.color.green)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } else {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> Error')
        .setDescription('Failed to remove the vouch.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
