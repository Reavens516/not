const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const config = require('../config.json');
const CatLoggr = require('cat-loggr');

const log = new CatLoggr();
const generated = new Set();

// Enhanced logging function
function logActivity(type, user, event, details) {
    const timestamp = new Date().toISOString();
    const logEntry = `[${timestamp}] ${type.toUpperCase()} - User: ${user} | Event: ${event} | Details: ${JSON.stringify(details)}\n`;
    
    // Write to log file
    try {
        if (!fs.existsSync('./logs')) {
            fs.mkdirSync('./logs');
        }
        fs.appendFileSync('./logs/activity.log', logEntry);
    } catch (error) {
        console.error('Logging error:', error);
    }
    
    // Also log to console
    log.info(`${type.toUpperCase()}: ${user} - ${event}`);
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('free')
        .setDescription('Generate a specified service if stocked')
        .addStringOption(option =>
            option.setName('service')
                .setDescription('The name of the service to generate')
                .setRequired(true)),

    async execute(interaction) {
    const userId = interaction.user.id;
    const userName = interaction.user.username;
        const service = interaction.options.getString('service');
        const member = interaction.member;

        // Check if the channel where the command was used is the generator channel
        if (interaction.channelId !== config.genChannel) {
            const wrongChannelEmbed = new MessageEmbed()
                .setColor(config.color.red)
                .setTitle('Wrong command usage!')
                .setDescription(`You cannot use the \`/free\` command in this channel! Try it in <#${config.genChannel}>!`)
                .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                .setTimestamp();

            return interaction.reply({ embeds: [wrongChannelEmbed], ephemeral: true });
        }

        // Check if the user has cooldown on the command
        if (generated.has(member.id)) {
            const cooldownEmbed = new MessageEmbed()
                .setColor(config.color.red)
                .setTitle('Cooldown!')
                .setDescription(`Please wait **${config.genCooldown}** seconds before executing that command again!`)
                .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                .setTimestamp();

            return interaction.reply({ embeds: [cooldownEmbed], ephemeral: true });
        }

        // File path to find the given service
        const filePath = `${__dirname}/../free/${service}.txt`;

        // Read the service file
        fs.readFile(filePath, 'utf-8', (error, data) => {
            if (error) {
                const notFoundEmbed = new MessageEmbed()
                    .setColor(config.color.red)
                    .setTitle('Generator error!')
                    .setDescription(`Service \`${service}\` does not exist!`)
                    .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                    .setTimestamp();

                return interaction.reply({ embeds: [notFoundEmbed], ephemeral: true });
            }

            const lines = data.split(/\r?\n/);

            if (lines.length <= 1) {
                const emptyServiceEmbed = new MessageEmbed()
                    .setColor(config.color.red)
                    .setTitle('Generator error!')
                    .setDescription(`The \`${service}\` service is empty!`)
                    .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                    .setTimestamp();

                return interaction.reply({ embeds: [emptyServiceEmbed], ephemeral: true });
            }

            const generatedAccount = lines[0];

            // Remove the redeemed account line
            lines.shift();
            const updatedData = lines.join('\n');

            // Write the updated data back to the file
            fs.writeFile(filePath, updatedData, (writeError) => {
                if (writeError) {
                    log.error(writeError);
                    return interaction.reply('An error occurred while redeeming the account.');
                }

                const productId = `FREE_${service.toUpperCase()}_${Date.now()}`;
                
                // Log successful generation
                logActivity('SUCCESS', member.user.tag, 'SERVICE_GENERATED', {
                  service: service,
                  account: generatedAccount,
                  userId: member.id,
                  productId: productId,
                  timestamp: new Date().toISOString()
                });

                // Send log to log channel
                const logChannel = interaction.client.channels.cache.get(config.logChannelId);
                if (logChannel) {
                    const logEmbed = new MessageEmbed()
                        .setColor(config.color.green)
                        .setTitle('🎁 Free Generation Log')
                        .addFields(
                            { name: 'User', value: `${member.user.tag} (${member.id})`, inline: true },
                            { name: 'Service', value: service, inline: true },
                            { name: 'Account', value: `||${generatedAccount}||`, inline: true },
                            { name: 'Product ID', value: productId, inline: false },
                            { name: 'Channel', value: `<#${interaction.channelId}>`, inline: true },
                            { name: 'Timestamp', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                        )
                        .setFooter({ text: 'Free Generation System' })
                        .setTimestamp();
                    
                    logChannel.send({ embeds: [logEmbed] }).catch(console.error);
                }

                const embedMessage = new MessageEmbed()
                    .setColor(config.color.green)
                    .setTitle('Generated account')
                    .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 }) })
                    .setDescription('Thank you for using our service!')
                    .addFields(
                        { name: 'Service', value: `\`\`\`${service[0].toUpperCase()}${service.slice(1).toLowerCase()}\`\`\``, inline: true },
                        { name: 'Account', value: `\`\`\`${generatedAccount}\`\`\``, inline: true },
                        { name: 'Product ID', value: `\`\`\`${productId}\`\`\``, inline: true }
                    )
                    .setImage(config.banner)
                    .setTimestamp();

                member.send({ embeds: [embedMessage] })
                    .catch(error => {
                      console.error(`Error sending embed message: ${error}`);
                      logActivity('ERROR', member.user.tag, 'DM_SEND_FAILED', {
                        service: service,
                        error: error.message
                      });
                    });
                interaction.reply({
                    content: `**Check your DM ${member}!** __If you do not receive the message, please unlock your private!__`,
                });

                generated.add(member.id);
                setTimeout(() => {
                    generated.delete(member.id);
                }, config.genCooldown * 1000);
            });
        });
    },
};