
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const VouchSystem = require('../vouch-system.js');
const config = require('../config.json');

const vouchSystem = new VouchSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vouches')
    .setDescription('View vouches for a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to view vouches for (optional)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const userVouches = vouchSystem.getUserVouches(targetUser.id);

    if (userVouches.total === 0) {
      const embed = new MessageEmbed()
        .setTitle('<:cross:1390238873086464072> No Vouches')
        .setDescription(`${targetUser} has no vouches yet.`)
        .setColor(config.color.yellow)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed] });
    }

    const embed = new MessageEmbed()
      .setTitle(`<:black_presente:1390239083527143468> ${targetUser.username}'s Vouches`)
      .setDescription(`**Score:** ${userVouches.score} | **Total:** ${userVouches.total}`)
      .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
      .setColor(userVouches.score >= 0 ? config.color.green : config.color.red)
      .setFooter({ text: config.footer })
      .setTimestamp();

    // Add positive vouches
    if (userVouches.positive.length > 0) {
      const positiveVouches = userVouches.positive
        .slice(-5) // Show last 5 vouches
        .map(v => {
          const date = new Date(v.timestamp).toLocaleDateString();
          return `**ID:** ${v.id}\n**Message:** ${v.message}\n**Date:** ${date}`;
        })
        .join('\n\n');

      embed.addFields({ 
        name: `<:black_presente:1390239083527143468> Positive Vouches (${userVouches.positive.length})`, 
        value: positiveVouches.length > 1024 ? positiveVouches.substring(0, 1020) + '...' : positiveVouches,
        inline: false 
      });
    }

    // Add negative vouches
    if (userVouches.negative.length > 0) {
      const negativeVouches = userVouches.negative
        .slice(-5) // Show last 5 vouches
        .map(v => {
          const date = new Date(v.timestamp).toLocaleDateString();
          return `**ID:** ${v.id}\n**Message:** ${v.message}\n**Date:** ${date}`;
        })
        .join('\n\n');

      embed.addFields({ 
        name: `<:cross:1390238873086464072> Negative Vouches (${userVouches.negative.length})`, 
        value: negativeVouches.length > 1024 ? negativeVouches.substring(0, 1020) + '...' : negativeVouches,
        inline: false 
      });
    }

    await interaction.reply({ embeds: [embed] });
  }
};
