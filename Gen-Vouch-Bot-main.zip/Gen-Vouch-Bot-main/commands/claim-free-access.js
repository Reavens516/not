const { SlashCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");
const InviteSystem = require("../invite-system.js");
const config = require("../config.json");

const inviteSystem = new InviteSystem();
const FREE_ACCESS_ROLE_ID = "1390008142896828446"; // Replace with actual role ID

module.exports = {
  data: new SlashCommandBuilder()
    .setName("claim-free-access")
    .setDescription("Claim free access role with 3 valid invites"),

  async execute(interaction) {
    const userId = interaction.user.id;
    const userData = inviteSystem.getUserInvites(userId);

    // Check if user can claim
    if (!inviteSystem.canClaimRole(userId)) {
      let reason = "";
      if (userData.validInvites < 3) {
        reason = `You need 3 valid invites to claim this role. You currently have ${userData.validInvites} valid invites.`;
      } else if (inviteSystem.isClaimActive(userId)) {
        const claim = inviteSystem.getUserClaim(userId);
        const daysLeft = Math.floor(
          (claim.expiresAt - Date.now()) / (1000 * 60 * 60 * 24),
        );
        reason = `You already have an active claim that expires in ${daysLeft} days.`;
      }

      const embed = new MessageEmbed()
        .setTitle("❌ Cannot Claim Role")
        .setDescription(reason)
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    try {
      // Try to add the role
      const member = await interaction.guild.members.fetch(userId);
      const role = await interaction.guild.roles.fetch(FREE_ACCESS_ROLE_ID);

      if (!role) {
        const embed = new MessageEmbed()
          .setTitle("❌ Role Not Found")
          .setDescription(
            "The free access role could not be found. Please contact an administrator.",
          )
          .setColor(config.color.red)
          .setFooter({ text: config.footer })
          .setTimestamp();

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      await member.roles.add(role);

      // Claim the role in the system
      inviteSystem.claimRole(userId);

      const embed = new MessageEmbed()
        .setTitle("🎉 Free Access Claimed!")
        .setDescription(
          `Congratulations! You have successfully claimed the **${role.name}** role for 1 week.\n\n3 invites have been deducted from your account.`,
        )
        .setColor(config.color.green)
        .addFields([
          { name: "⏰ Duration", value: "7 days", inline: true },
          { name: "📊 Invites Used", value: "3", inline: true },
          { name: "📈 Total Claim Invites", value: (userData.claimInvites + 3).toString(), inline: true },
        ])
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error("Error claiming role:", error);

      const embed = new MessageEmbed()
        .setTitle("❌ Error")
        .setDescription(
          "An error occurred while trying to claim the role. Please try again later.",
        )
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
