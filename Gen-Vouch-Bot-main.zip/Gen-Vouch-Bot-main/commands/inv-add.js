
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const InviteSystem = require('../invite-system.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const inviteSystem = new InviteSystem();
const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inv-add')
    .setDescription('[ADMIN] Add invites to a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to add invites to')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Number of invites to add')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    ),

  async execute(interaction) {
    if (!adminSystem.isAdmin(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only admins can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    // Manually add invites
    const data = inviteSystem.getInviteData();
    if (!data[targetUser.id]) {
      data[targetUser.id] = {
        totalInvites: 0,
        validInvites: 0,
        fakeInvites: 0,
        rejoinInvites: 0,
        invited: []
      };
    }

    data[targetUser.id].validInvites += amount;
    data[targetUser.id].totalInvites += amount;
    inviteSystem.saveInviteData(data);

    const embed = new MessageEmbed()
      .setTitle('✅ Invites Added')
      .setDescription(`Successfully added ${amount} invites to ${targetUser.tag}.`)
      .setColor(config.color.green)
      .addFields([
        { name: '👤 User', value: targetUser.tag, inline: true },
        { name: '➕ Added', value: amount.toString(), inline: true },
        { name: '📊 New Total', value: data[targetUser.id].validInvites.toString(), inline: true }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
