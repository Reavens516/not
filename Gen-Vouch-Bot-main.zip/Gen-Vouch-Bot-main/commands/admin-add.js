
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin-add')
    .setDescription('[OWNER ONLY] Add a new admin')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to make admin')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('level')
        .setDescription('Admin level')
        .setRequired(true)
        .addChoices(
          { name: 'Admin', value: 'admin' },
          { name: 'Moderator', value: 'moderator' },
          { name: 'Helper', value: 'helper' }
        )
    ),

  async execute(interaction) {
    if (!adminSystem.isOwner(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only the bot owner can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const targetUser = interaction.options.getUser('user');
    const level = interaction.options.getString('level');

    if (adminSystem.isAdmin(targetUser.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Already Admin')
        .setDescription(`${targetUser.tag} is already an admin.`)
        .setColor(config.color.yellow)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    adminSystem.addAdmin(targetUser.id, level, interaction.user.id);

    const embed = new MessageEmbed()
      .setTitle('✅ Admin Added')
      .setDescription(`Successfully added ${targetUser.tag} as ${level}.`)
      .setColor(config.color.green)
      .addFields([
        { name: '👤 User', value: targetUser.tag, inline: true },
        { name: '🎭 Level', value: level, inline: true },
        { name: '👑 Added By', value: interaction.user.tag, inline: true }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
