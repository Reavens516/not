
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('[ADMIN] Send an embed message')
    .addStringOption(option =>
      option.setName('title')
        .setDescription('Embed title')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('description')
        .setDescription('Embed description')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('color')
        .setDescription('Embed color')
        .setRequired(false)
        .addChoices(
          { name: 'Green', value: 'green' },
          { name: 'Red', value: 'red' },
          { name: 'Yellow', value: 'yellow' },
          { name: 'Default', value: 'default' }
        )
    )
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel to send embed to (optional)')
        .setRequired(false)
    ),

  async execute(interaction) {
    if (!adminSystem.isAdmin(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only admins can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const title = interaction.options.getString('title');
    const description = interaction.options.getString('description');
    const color = interaction.options.getString('color') || 'default';
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    try {
      const embed = new MessageEmbed()
        .setTitle(title)
        .setDescription(description)
        .setColor(config.color[color])
        .setFooter({ text: config.footer })
        .setTimestamp();

      await channel.send({ embeds: [embed] });
      
      const confirmEmbed = new MessageEmbed()
        .setTitle('✅ Embed Sent')
        .setDescription(`Embed sent to ${channel}.`)
        .setColor(config.color.green)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });
    } catch (error) {
      const embed = new MessageEmbed()
        .setTitle('❌ Error')
        .setDescription('Failed to send embed.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
