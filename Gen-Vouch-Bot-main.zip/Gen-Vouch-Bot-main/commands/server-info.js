
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('server-info')
    .setDescription('Display server information'),

  async execute(interaction) {
    const guild = interaction.guild;
    
    const embed = new MessageEmbed()
      .setTitle(`📊 ${guild.name} Server Info`)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 512 }))
      .setColor(config.color.default)
      .addFields([
        { name: '👑 Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: '📅 Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
        { name: '🆔 Server ID', value: guild.id, inline: true },
        { name: '👥 Members', value: guild.memberCount.toString(), inline: true },
        { name: '💬 Channels', value: guild.channels.cache.size.toString(), inline: true },
        { name: '🎭 Roles', value: guild.roles.cache.size.toString(), inline: true },
        { name: '😀 Emojis', value: guild.emojis.cache.size.toString(), inline: true },
        { name: '🚀 Boost Level', value: guild.premiumTier.toString(), inline: true },
        { name: '💎 Boosts', value: guild.premiumSubscriptionCount?.toString() || '0', inline: true }
      ])
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
