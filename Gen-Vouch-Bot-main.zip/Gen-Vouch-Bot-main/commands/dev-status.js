
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const AdminSystem = require('../admin-system.js');
const config = require('../config.json');

const adminSystem = new AdminSystem();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dev-status')
    .setDescription('[DEV] Change bot status')
    .addStringOption(option =>
      option.setName('activity')
        .setDescription('Activity text')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('type')
        .setDescription('Activity type')
        .setRequired(false)
        .addChoices(
          { name: 'Playing', value: 'PLAYING' },
          { name: 'Watching', value: 'WATCHING' },
          { name: 'Listening', value: 'LISTENING' },
          { name: 'Competing', value: 'COMPETING' }
        )
    ),

  async execute(interaction) {
    if (!adminSystem.isOwner(interaction.user.id)) {
      const embed = new MessageEmbed()
        .setTitle('❌ Access Denied')
        .setDescription('Only developers can use this command.')
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const activity = interaction.options.getString('activity');
    const type = interaction.options.getString('type') || 'WATCHING';

    try {
      interaction.client.user.setActivity(activity, { type: type });

      const embed = new MessageEmbed()
        .setTitle('✅ Status Updated')
        .setDescription(`Bot status changed to: **${type.toLowerCase()}** ${activity}`)
        .setColor(config.color.green)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (error) {
      const embed = new MessageEmbed()
        .setTitle('❌ Error')
        .setDescription(`Failed to change status: ${error.message}`)
        .setColor(config.color.red)
        .setFooter({ text: config.footer })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
