
const fs = require('fs');
const path = require('path');

class AdminSystem {
  constructor() {
    this.adminsPath = './data/admins.json';
    this.BOT_OWNER_ID = '1383706658315960330'; // Your ID
    this.ensureDataFiles();
  }

  ensureDataFiles() {
    const dataDir = './data';
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    if (!fs.existsSync(this.adminsPath)) {
      // Initialize with bot owner
      const initialData = {
        [this.BOT_OWNER_ID]: {
          level: 'owner',
          addedBy: 'system',
          addedAt: Date.now()
        }
      };
      fs.writeFileSync(this.adminsPath, JSON.stringify(initialData, null, 2));
    }
  }

  getAdminData() {
    try {
      return JSON.parse(fs.readFileSync(this.adminsPath, 'utf8'));
    } catch (error) {
      return {};
    }
  }

  saveAdminData(data) {
    fs.writeFileSync(this.adminsPath, JSON.stringify(data, null, 2));
  }

  isOwner(userId) {
    return userId === this.BOT_OWNER_ID;
  }

  isAdmin(userId) {
    const admins = this.getAdminData();
    return admins[userId] || this.isOwner(userId);
  }

  getAdminLevel(userId) {
    if (this.isOwner(userId)) return 'owner';
    const admins = this.getAdminData();
    return admins[userId]?.level || null;
  }

  addAdmin(userId, level, addedBy) {
    const admins = this.getAdminData();
    admins[userId] = {
      level: level,
      addedBy: addedBy,
      addedAt: Date.now()
    };
    this.saveAdminData(admins);
    return true;
  }

  removeAdmin(userId) {
    if (this.isOwner(userId)) return false; // Cannot remove owner
    const admins = this.getAdminData();
    delete admins[userId];
    this.saveAdminData(admins);
    return true;
  }

  getAllAdmins() {
    return this.getAdminData();
  }
}

module.exports = AdminSystem;
