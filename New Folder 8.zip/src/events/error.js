module.exports = async (bot, err) => {
    console.log(`${require("../modules/utils").errorPrefix}${err}`);
};
